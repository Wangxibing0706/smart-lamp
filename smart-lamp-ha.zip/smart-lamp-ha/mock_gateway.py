"""模拟乐逗灯泡网关：UDP 广播发现 + TCP 41330 控制，用于端到端验证 smart-lamp 服务。

协议（逆向自 smart-lamp 源码）：
- UDP 41328：网关广播，字节[2:6] = gatewayId(LE int32)，[21]/[22] = 设备计数
- TCP 41330：客户端连接后发送请求
  - f3 d4 ... (15字节) = 获取灯泡列表 → 响应 10 字节头 + body，头[9] = body 长度
    body 每 8 字节一个灯泡: [id LE int32][blue][green][red][intensity]
  - f2 c2 ... = 更新灯泡 → 响应 10 字节头（头[9]=0 表示无 body）
"""
import socket
import struct
import threading
import time

UDP_PORT = 41328
TCP_PORT = 41330
GATEWAY_ID = 1

# 初始灯泡状态: (id, intensity, red, green, blue)
lamps = {
    1: {"intensity": 255, "red": 255, "green": 255, "blue": 255},
    2: {"intensity": 128, "red": 255, "green": 0, "blue": 0},
}
lock = threading.Lock()


def udp_broadcaster():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    while True:
        pkt = bytearray(32)
        struct.pack_into("<i", pkt, 2, GATEWAY_ID)
        pkt[21] = 1
        pkt[22] = len(lamps)
        try:
            sock.sendto(bytes(pkt), ("127.0.0.1", UDP_PORT))
        except OSError:
            pass
        time.sleep(2)


def handle_tcp(conn):
    with conn:
        conn.settimeout(5)
        try:
            data = conn.recv(1024)
        except socket.timeout:
            return
        if len(data) < 2:
            return
        if data[0] == 0xF3 and data[1] == 0xD4:
            # 获取灯泡列表
            with lock:
                body = b""
                for lid, st in lamps.items():
                    body += struct.pack("<i", lid)
                    body += bytes([st["blue"], st["green"], st["red"], st["intensity"]])
            header = bytearray(10)
            header[9] = len(body)
            conn.sendall(bytes(header) + body)
            print(f"[mock] GetLamps -> {len(lamps)} lamps")
        elif data[0] == 0xF2 and data[1] == 0xC2:
            # 更新灯泡（头部 14 字节：f2 c2 ff ff ff ff 00 00 1d <len> 00 00 00 43）
            count = (len(data) - 14) // 8
            with lock:
                for i in range(count):
                    off = 14 + i * 8
                    lid = struct.unpack_from("<i", data, off)[0]
                    blue, green, red, intensity = data[off + 4], data[off + 5], data[off + 6], data[off + 7]
                    lamps[lid] = {"intensity": intensity, "red": red, "green": green, "blue": blue}
            print(f"[mock] UpdateLamps -> {count} lamps, state={lamps}")
            conn.sendall(bytes(10))
        else:
            print(f"[mock] unknown request: {data.hex()}")
            conn.sendall(bytes(10))


def tcp_server():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", TCP_PORT))
    srv.listen(5)
    print(f"[mock] TCP gateway listening on {TCP_PORT}")
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=handle_tcp, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    threading.Thread(target=udp_broadcaster, daemon=True).start()
    tcp_server()
