"""The Smart Lamp integration."""
from __future__ import annotations

import logging
from datetime import timedelta

import aiohttp
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_PORT, CONF_SCAN_INTERVAL, Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DEFAULT_SCAN_INTERVAL, DOMAIN, LOGGER

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [Platform.LIGHT]


class SmartLampHub:
    """HTTP client for the yon1ng/smart-lamp REST service."""

    def __init__(self, host: str, port: int, session: aiohttp.ClientSession) -> None:
        self._host = host
        self._port = port
        self._session = session
        self._base_url = f"http://{host}:{port}"

    async def async_get_status(self) -> dict:
        """GET /status -> parsed data payload."""
        async with self._session.get(
            f"{self._base_url}/status", timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            resp.raise_for_status()
            payload = await resp.json()
        return payload

    async def async_set_lamp_state(
        self, device_id: int, intensity: int, red: int, green: int, blue: int
    ) -> None:
        """GET /on?deviceId=..&intensity=..&r=..&g=..&b=.."""
        params = {
            "deviceId": device_id,
            "intensity": intensity,
            "r": red,
            "g": green,
            "b": blue,
        }
        async with self._session.get(
            f"{self._base_url}/on",
            params=params,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            resp.raise_for_status()

    async def async_lamp_off(self, device_id: int) -> None:
        """GET /off?deviceId=.."""
        async with self._session.get(
            f"{self._base_url}/off",
            params={"deviceId": device_id},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            resp.raise_for_status()


class SmartLampCoordinator(DataUpdateCoordinator):
    """Poll the smart-lamp service and keep lamp states fresh."""

    def __init__(
        self, hass: HomeAssistant, hub: SmartLampHub, scan_interval: int
    ) -> None:
        super().__init__(
            hass,
            LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=scan_interval),
        )
        self.hub = hub

    async def _async_update_data(self) -> dict:
        try:
            payload = await self.hub.async_get_status()
        except Exception as err:  # noqa: BLE001 - report any transport issue
            raise UpdateFailed(f"Cannot reach smart-lamp service: {err}") from err

        if not isinstance(payload, dict) or payload.get("code") != "0000":
            raise UpdateFailed("smart-lamp service returned an unexpected payload")

        data = payload.get("data") or {}
        lamps: dict[int, dict] = {}
        raw_lamps = (data.get("lamps") or {}).get("raw") or []
        for item in raw_lamps:
            try:
                lamp_id = int(item["id"])
                lamps[lamp_id] = {
                    "intensity": int(item.get("intensity", 0)),
                    "red": int(item.get("red", 0)),
                    "green": int(item.get("green", 0)),
                    "blue": int(item.get("blue", 0)),
                }
            except (KeyError, TypeError, ValueError):
                continue
        data["lamps"] = lamps
        return data


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Smart Lamp from a config entry."""
    host = entry.data[CONF_HOST]
    port = entry.data[CONF_PORT]
    scan_interval = entry.data.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)

    hub = SmartLampHub(host, port, async_get_clientsession(hass))
    coordinator = SmartLampCoordinator(hass, hub, scan_interval)
    await coordinator.async_config_entry_first_refresh()

    entry.runtime_data = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    return await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
