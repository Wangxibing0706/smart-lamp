# Keelight / 乐逗智能灯泡 · Home Assistant 控制方案

基于 [yon1ng/smart-lamp](https://github.com/yon1ng/smart-lamp) 项目，通过 **HACS 自定义集成** 在 Home Assistant 中控制 Keelight / 乐逗智能灯泡。

## 架构

```
Home Assistant ──HTTP(8080)──▶ smart-lamp 服务 ──UDP 41328 / TCP 41330──▶ 灯泡网关 ──▶ 各灯泡
   (HACS 集成)                 (Java 服务/NAS)                        (乐逗硬件)
```

- **smart-lamp 服务**：运行在你的 NAS / 软路由 / 任意常开主机上，负责与灯泡网关通信，暴露 REST 接口（`/status`、`/on`、`/off`）
- **HACS 集成**：安装在 Home Assistant 中，把每个灯泡变成一个标准的 `light` 实体（开关 / 亮度 / RGB 颜色）

## 前置条件

1. Home Assistant 已安装并配置好 **HACS**
2. 灯泡已通过「乐逗」App 正常配网、与网关通信正常（本方案复用现有网关，无需重新配网）
3. 运行 smart-lamp 服务的主机与灯泡网关在**同一局域网**
4. 该主机有 Docker（推荐）或 JDK 11+ 运行环境

---

## 第一步：部署 smart-lamp 服务

### 方式 A：Docker（推荐，适合 NAS / 软路由）

```bash
cd server
docker compose up -d
```

验证服务是否正常：

```bash
curl http://<服务主机IP>:8080/status
```

返回类似下面的 JSON 即正常（`raw` 数组里是各灯泡的状态，实际还会多返回 `alias`、`bytes` 字段，集成会自动忽略）：

```json
{
  "code": "0000",
  "msg": "success",
  "data": {
    "state": "CONNECTED",
    "allOff": true,
    "lamps": {
      "raw": [
        {"id": 323, "intensity": 255, "red": 255, "green": 255, "blue": 0}
      ],
      "length": 1,
      "empty": false
    }
  }
}
```

> **关于网关发现**：服务通过 UDP 广播（41328）被动发现网关，网关广播周期不固定（实测从十几秒到数分钟不等）。刚启动时 `lamps.raw` 可能短暂为空，等待即可；持续为空则确认网关是否在线。本方案已在真实网关环境验证：自动发现网关、读取真实灯泡状态、控制命令全部生效。

### 方式 B：直接运行 Jar（无需 Docker）

`server/smart-lamp-1.0.jar` 为预编译成品（Java 11+）：

```bash
java -jar smart-lamp-1.0.jar
# 默认监听 8080 端口，保持前台运行或用 systemd/nohup 常驻
```

### 方式 C：自行编译

```bash
cd server
mvn package -DskipTests
java -jar target/smart-lamp-1.0.jar
```

> 说明：已从 pom.xml 移除 spring-native 实验性插件（仅服务于 GraalVM 原生镜像），普通 Jar 构建更稳定，运行行为不变。
>
> 另修复了原项目一个 bug：`Collection.equals()` 在两次读取的灯泡数量不一致时会抛 `ArrayIndexOutOfBoundsException` 导致 `/on`、`/off` 接口返回 500（已改为返回 false，控制命令不受影响）。

---

## 第二步：安装 HACS 集成

### 方式 A：HACS 自定义仓库（推荐，可更新）

1. 把本目录下的 `hacs-repo` 文件夹推到你的 GitHub 仓库（仓库根目录需包含 `custom_components/smart_lamp/`）
2. Home Assistant → **HACS** → 右上角 ⋮ → **自定义仓库 (Custom repositories)**
3. 仓库地址填你的 GitHub 仓库 URL，类别选 **集成 (Integration)**，点击添加
4. 在 HACS 中搜索 **Smart Lamp** → 下载 → 重启 Home Assistant

### 方式 B：手动安装

1. 用 Samba / SSH / File Editor 等工具，把 `hacs-repo/custom_components/smart_lamp` 整个文件夹复制到 HA 配置目录：
   ```
   <HA配置目录>/custom_components/smart_lamp/
   ```
2. 重启 Home Assistant

---

## 第三步：添加集成

1. HA → **设置** → **设备与服务** → **添加集成**
2. 搜索 **Smart Lamp**（或"智能灯泡"）
3. 填写：
   - **主机地址**：smart-lamp 服务的 IP，如 `192.168.1.10`
   - **端口**：默认 `8080`
   - **名称**：随意，如"乐逗灯泡"
   - **轮询间隔**：默认 10 秒（范围 2~300）
4. 提交后，每个灯泡会自动创建一个 `light` 实体

## 实体说明

| 功能 | 支持情况 |
|------|----------|
| 开关 | ✅ |
| 亮度 (0-255) | ✅ |
| RGB 颜色 | ✅ |
| 状态同步 | 按轮询间隔自动刷新 |
| 新增灯泡 | 自动发现，无需重配 |

实体命名：`灯泡 1`、`灯泡 2`……（按网关上报的 deviceId），可在 HA 里随意改名。

---

## 常见问题

**添加集成时提示"无法连接"**
- 确认 `curl http://IP:8080/status` 在电脑上能通
- 检查主机防火墙是否放行 8080
- Docker 用户确认用了 `network_mode: host`

**实体不出现 / 显示不可用**
- 看 `/status` 返回里 `lamps.raw` 是否有数据；为空说明网关侧没发现灯泡
- 确认灯泡在乐逗 App 里在线

**控制延迟**
- 协议本身有约 200ms 的请求限速，加上轮询间隔，状态刷新有秒级延迟属正常现象

**安全性**
- 服务无鉴权，**仅限内网使用**，切勿映射到公网

## 文件清单

```
smart-lamp-ha/
├── README.md                      ← 本文档
├── hacs-repo/                     ← HACS 集成（推到 GitHub 后用 HACS 添加自定义仓库）
│   └── custom_components/smart_lamp/
│       ├── __init__.py            ← 服务连接 + 状态轮询
│       ├── config_flow.py         ← UI 配置流程
│       ├── light.py               ← 灯泡实体（开关/亮度/颜色）
│       ├── manifest.json
│       └── strings.json / translations/
├── server/                        ← smart-lamp 服务端
│   ├── Dockerfile / docker-compose.yml
│   ├── smart-lamp-1.0.jar         ← 预编译 Jar（Java 11+，已修复 equals bug）
│   └── pom.xml / src/             ← 源码（含清理后的 pom）
└── mock_gateway.py                ← 开发调试工具：Python 模拟网关（仅限无真实网关的环境测试用）
```

> `mock_gateway.py` 是开发时用来模拟网关的测试工具，**不要在连接着真实网关的网络上运行**（会干扰真实网关发现）。
