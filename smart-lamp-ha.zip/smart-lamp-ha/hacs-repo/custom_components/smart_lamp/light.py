"""Light platform for the Smart Lamp integration."""
from __future__ import annotations

from typing import Any

from homeassistant.components.light import (
    ATTR_BRIGHTNESS,
    ATTR_RGB_COLOR,
    ColorMode,
    LightEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from . import SmartLampCoordinator
from .const import CONF_LAMP_PREFIX


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up light entities, discovering lamps from the service."""
    coordinator: SmartLampCoordinator = entry.runtime_data
    known_ids: set[int] = set()

    @callback
    def _discover_lamps() -> None:
        new_ids = set(coordinator.data.get("lamps", {})) - known_ids
        if not new_ids:
            return
        entities = [SmartLampLight(coordinator, lamp_id) for lamp_id in sorted(new_ids)]
        known_ids.update(new_ids)
        async_add_entities(entities)

    coordinator.async_add_listener(_discover_lamps)
    _discover_lamps()


class SmartLampLight(CoordinatorEntity, LightEntity):
    """Representation of a single Keelight/Ledo lamp."""

    _attr_color_mode = ColorMode.RGB
    _attr_supported_color_modes = {ColorMode.RGB}
    _attr_has_entity_name = True

    def __init__(self, coordinator: SmartLampCoordinator, lamp_id: int) -> None:
        super().__init__(coordinator)
        self._lamp_id = lamp_id
        self._attr_unique_id = f"{coordinator.config_entry.entry_id}_{lamp_id}"
        self._attr_name = f"{CONF_LAMP_PREFIX} {lamp_id}"

    @property
    def _lamp(self) -> dict | None:
        return self.coordinator.data.get("lamps", {}).get(self._lamp_id)

    @property
    def available(self) -> bool:
        return self.coordinator.last_update_success and self._lamp is not None

    @property
    def is_on(self) -> bool:
        lamp = self._lamp
        return bool(lamp and lamp.get("intensity", 0) > 0)

    @property
    def brightness(self) -> int | None:
        lamp = self._lamp
        return lamp.get("intensity") if lamp else None

    @property
    def rgb_color(self) -> tuple[int, int, int] | None:
        lamp = self._lamp
        if not lamp:
            return None
        return (lamp.get("red", 0), lamp.get("green", 0), lamp.get("blue", 0))

    async def async_turn_on(self, **kwargs: Any) -> None:
        lamp = self._lamp or {}

        rgb = kwargs.get(ATTR_RGB_COLOR)
        if rgb is None:
            current = (lamp.get("red", 0), lamp.get("green", 0), lamp.get("blue", 0))
            # A lamp that has never been lit reports 0,0,0 -> default to white
            rgb = current if any(current) else (255, 255, 255)

        brightness = kwargs.get(ATTR_BRIGHTNESS)
        intensity = brightness if brightness is not None else (lamp.get("intensity") or 255)

        await self.coordinator.hub.async_set_lamp_state(
            self._lamp_id, intensity, rgb[0], rgb[1], rgb[2]
        )
        await self.coordinator.async_request_refresh()

    async def async_turn_off(self, **kwargs: Any) -> None:
        await self.coordinator.hub.async_lamp_off(self._lamp_id)
        await self.coordinator.async_request_refresh()
