# Smart Lamp — Home Assistant custom integration

Keelight / 乐逗智能灯泡 的 Home Assistant 自定义集成，通过 [yon1ng/smart-lamp](https://github.com/yon1ng/smart-lamp) 服务控制灯泡。

## 安装

HACS → 自定义仓库 → 添加本仓库地址（类别：集成）→ 搜索 "Smart Lamp" 下载 → 重启 HA。

## 配置

设置 → 设备与服务 → 添加集成 → Smart Lamp → 填写 smart-lamp 服务的主机 IP 和端口（默认 8080）。

详细部署指南见主仓库 README。
