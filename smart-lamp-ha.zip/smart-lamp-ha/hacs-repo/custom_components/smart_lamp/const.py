"""Constants for the Smart Lamp integration."""
from __future__ import annotations

import logging

DOMAIN = "smart_lamp"
LOGGER = logging.getLogger(__package__)

DEFAULT_NAME = "Smart Lamp"
DEFAULT_PORT = 8080
DEFAULT_SCAN_INTERVAL = 10

CONF_LAMP_PREFIX = "灯泡"
